﻿Public Class Form4
    Dim score As Integer = 0

    Private Sub SplitContainer1_Panel1_Paint_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles SplitContainer1.Panel1.Paint
        btn3.Enabled = False
        btn4.Enabled = False
        btn5.Enabled = False
        btn6.Enabled = False
        btn7.Enabled = False
        btn8.Enabled = False
        btn9.Enabled = False
        btn10.Enabled = False
        btn11.Enabled = False
        btn12.Enabled = False
        btn13.Enabled = False
        btn14.Enabled = False
        btn15.Enabled = False
        btn16.Enabled = False
        btn17.Enabled = False
        btn18.Enabled = False
        btn19.Enabled = False
        btn20.Enabled = False
        LabelQuestion.Hide()
        btnchoice1.Hide()
        btnchoice2.Hide()
        btnchoice3.Hide()
        btnchoice4.Hide()
        btnNext.Hide()
        LabelScore.Hide()

    End Sub

    Private Sub btn2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn2.Click
        LabelQuestion.Show()
        btnchoice1.Show()
        btnchoice2.Show()
        btnchoice3.Show()
        btnchoice4.Show()
    End Sub

    Private Sub SplitContainer1_Panel2_Paint_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles SplitContainer1.Panel2.Paint
        btnchoice1.Text = "True"
        btnchoice2.Text = "Sometimes False"
        btnchoice3.Text = "Sometimes True"
        btnchoice4.Text = "False"
    End Sub

    Private Sub CheckAnswer(ByVal selectedChoice As String, ByVal selectedButton As Button, ByVal correctAnswer As String)
        ' Check the user's answer
        If selectedChoice = correctAnswer Then
            selectedButton.BackColor = Color.Green
            score += 100
            UpdateScore()

            ' Ask if the user wants to go to the next level
            If selectedChoice = correctAnswer Then
                btnchoice1.Enabled = False
                btnchoice2.Enabled = False
                btnchoice3.Enabled = False
                btnchoice4.Enabled = False
                btnNext.Show()
                LabelScore.Show()
            End If
        Else
            score -= 8 Xor 12 Xor 15
            selectedButton.BackColor = Color.Red
        End If
    End Sub

    Private Sub UpdateScore()
        ' Update and display the score
        LabelScore.Text = "Score: " & score.ToString()
    End Sub

    Private Sub btnchoice1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnchoice1.Click
        CheckAnswer(btnchoice1.Text, btnchoice1, "True")
        btnchoice1.Enabled = False

    End Sub

    Private Sub btnchoice2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnchoice2.Click
        CheckAnswer(btnchoice2.Text, btnchoice2, "incorrect")
        btnchoice2.Enabled = False
    End Sub

    Private Sub btnchoice3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnchoice3.Click
        CheckAnswer(btnchoice3.Text, btnchoice3, "incorrect")
        btnchoice3.Enabled = False
    End Sub

    Private Sub btnchoice4_AutoSizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnchoice4.AutoSizeChanged

    End Sub

    Private Sub btnchoice4_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnchoice4.Click
        CheckAnswer(btnchoice4.Text, btnchoice4, "Incorrect")
        btnchoice4.Enabled = False
    End Sub

    Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click
        Me.Hide()
        Dim nextLevelForm As New Form5()
        nextLevelForm.StartPosition = FormStartPosition.CenterScreen
        nextLevelForm.Show()
    End Sub

    Private Sub btnExit_MouseEnter(ByVal sender As Object, ByVal e As EventArgs) Handles btnExit.MouseEnter
        ' Change the button color to red when the mouse enters
        btnExit.BackColor = Color.Red
    End Sub

    Private Sub btnExit_MouseLeave(ByVal sender As Object, ByVal e As EventArgs) Handles btnExit.MouseLeave
        ' Revert the button color to the original color when the mouse leaves
        btnExit.BackColor = SystemColors.Control ' Use the default button color or set it to your desired color
    End Sub

    Private Sub btnExit_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub
    Private Sub btnMinimize_MouseEnter(ByVal sender As Object, ByVal e As EventArgs) Handles btnMinimize.MouseEnter
        ' Change the button color to gray when the mouse enters
        btnMinimize.BackColor = Color.Gray
    End Sub

    Private Sub btnMinimize_MouseLeave(ByVal sender As Object, ByVal e As EventArgs) Handles btnMinimize.MouseLeave
        ' Revert the button color to the original color when the mouse leaves
        btnMinimize.BackColor = SystemColors.Control ' Use the default button color or set it to your desired color
    End Sub
    Private Sub btnMinimize_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMinimize.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub btnBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBack.Click
        Me.Hide()
        Dim form1Instance As New Form3()
        form1Instance.StartPosition = FormStartPosition.CenterScreen
        form1Instance.Show()
    End Sub
    Private Sub btnBack_MouseLeave(ByVal sender As Object, ByVal e As EventArgs) Handles btnBack.MouseLeave
        btnBack.BackColor = SystemColors.Control
    End Sub
    Private Sub btnBack_MouseEnter(ByVal sender As Object, ByVal e As EventArgs) Handles btnBack.MouseEnter
        btnBack.BackColor = Color.Gray
    End Sub
End Class