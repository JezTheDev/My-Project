﻿Imports System.Data.OleDb
Public Class Registrationform
    Dim mycon As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\Registration.accdb")

    Private Sub Registerbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Registerbtn.Click
        mycon.Open()
        Dim mycmd As New OleDbCommand("Insert into Account (FName,Username,Password,ConfirmPassword) Values ('" & txtbxName.Text & "','" & txtbxUserName.Text & "','" & txtbxPassword.Text & "','" & txtbxConfirmPass.Text & "')", mycon)

        Try

            mycmd.ExecuteNonQuery()
            mycon.Close()
            txtbxName.Clear()
            txtbxUserName.Clear()
            txtbxPassword.Clear()
            txtbxConfirmPass.Clear()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class