﻿Public Class FinishLevel


    Private Sub btnExit_MouseEnter(ByVal sender As Object, ByVal e As EventArgs) Handles btnExit.MouseEnter
        btnExit.BackColor = Color.Red
    End Sub

    Private Sub btnExit_MouseLeave(ByVal sender As Object, ByVal e As EventArgs) Handles btnExit.MouseLeave
        btnExit.BackColor = SystemColors.Control
    End Sub

    Private Sub btnExit_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub
    Private Sub btnMinimize_MouseEnter(ByVal sender As Object, ByVal e As EventArgs) Handles btnMinimize.MouseEnter
        btnMinimize.BackColor = Color.Gray
    End Sub

    Private Sub btnMinimize_MouseLeave(ByVal sender As Object, ByVal e As EventArgs) Handles btnMinimize.MouseLeave
        btnMinimize.BackColor = SystemColors.Control
    End Sub
    Private Sub btnMinimize_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMinimize.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub btnBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Hide()
        Dim MainForm As New DashBoard()
        MainForm.StartPosition = FormStartPosition.CenterScreen
        MainForm.Show()
    End Sub
    Private Sub lblGameInstructions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        MessageBox.Show("Welcome to the game! Instructions:" & Chr(13) & "1.Click Level 1 to start the game." & Chr(13) & "2.Choose the correct answer from the choices." & Chr(13) & "3.Click Next to move to the next level.", "Game Instructions", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub
    Private Sub lblGameInstructions_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs)
        lblGameInstructions.BackColor = Color.Gray
    End Sub
    Private Sub lblGameInstructions_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs)
        lblGameInstructions.BackColor = SystemColors.Control
    End Sub
End Class