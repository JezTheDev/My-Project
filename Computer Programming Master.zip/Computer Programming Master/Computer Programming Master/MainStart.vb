﻿Public Class MainStart

    Dim i As Integer
    Public Sub New()
        InitializeComponent()
        Me.StartPosition = FormStartPosition.CenterScreen
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ProgressBar1.Hide()
    End Sub
    Private Sub LblStart_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LblStart.Click

        ProgressBar1.Show()
        LblStart.Visible = False
        Timer1.Enabled = True
        ProgressBar1.Maximum = 100
        i = 1

    End Sub

    Private Sub Timer1_Tick_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick

        ProgressBar1.Value = ProgressBar1.Value + 1
        Label2.Text = "Please wait... " & i & " % "
        i += 1
        If i > 100 Then
            Timer1.Enabled = False
            Me.Hide()
            Dim StartGame As New DashBoard()
            StartGame.StartPosition = FormStartPosition.CenterScreen
            StartGame.Show()
        End If

    End Sub

    Private Sub btnExit_MouseEnter(ByVal sender As Object, ByVal e As EventArgs) Handles btnExit.MouseEnter
        btnExit.BackColor = Color.Red
    End Sub

    Private Sub btnExit_MouseLeave(ByVal sender As Object, ByVal e As EventArgs) Handles btnExit.MouseLeave
        btnExit.BackColor = SystemColors.Control
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub
    Private Sub btnMinimize_MouseEnter(ByVal sender As Object, ByVal e As EventArgs) Handles btnMinimize.MouseEnter
        btnMinimize.BackColor = Color.Gray
    End Sub

    Private Sub btnMinimize_MouseLeave(ByVal sender As Object, ByVal e As EventArgs) Handles btnMinimize.MouseLeave
        btnMinimize.BackColor = SystemColors.Control
    End Sub
    Private Sub btnMinimize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMinimize.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub
End Class
