﻿Public Class DashBoard

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Hide()
        Dim Level As New Level1()
        Level.StartPosition = FormStartPosition.CenterScreen
        Level.Show()
    End Sub

    Private Sub btnExit_MouseEnter(ByVal sender As Object, ByVal e As EventArgs) Handles btnExit.MouseEnter
        btnExit.BackColor = Color.Red
    End Sub

    Private Sub btnExit_MouseLeave(ByVal sender As Object, ByVal e As EventArgs) Handles btnExit.MouseLeave
        btnExit.BackColor = SystemColors.Control
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub
    Private Sub btnMinimize_MouseEnter(ByVal sender As Object, ByVal e As EventArgs) Handles btnMinimize.MouseEnter
        btnMinimize.BackColor = Color.Gray
    End Sub

    Private Sub btnMinimize_MouseLeave(ByVal sender As Object, ByVal e As EventArgs) Handles btnMinimize.MouseLeave
        btnMinimize.BackColor = SystemColors.Control
    End Sub
    Private Sub btnMinimize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMinimize.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub btnBack_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBack.Click
        Me.Hide()
        Dim MainForm As New MainStart()
        MainForm.StartPosition = FormStartPosition.CenterScreen
        MainForm.Show()
    End Sub

    Private Sub btnBack_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBack.MouseLeave
        btnBack.ForeColor = Color.Black
    End Sub

    Private Sub btnBack_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBack.MouseEnter
        btnBack.ForeColor = Color.Aqua
    End Sub
End Class