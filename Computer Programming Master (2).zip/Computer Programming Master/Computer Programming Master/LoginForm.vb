﻿Imports System.Data.SqlClient

Public Class LoginForm
    ' Connection string to the database
    Dim connectionString As String = "Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\velas\OneDrive\Documents\My-Project\Computer Programming Master\Computer Programming Master\RegistrationDB.mdf;Integrated Security=True;User Instance=True"

    ' SQL query to check for user existence during login
    Dim sqlSelectUser As String = "SELECT * FROM Account WHERE Username=@Username AND Password=@Password"

    ' Event handler for the Login button click
    Private Sub Loginbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Loginbtn.Click
        Try
            ' Check if the entered username and password exist in the database
            If UserExists(txtUserName.Text, txtPassword.Text) Then
                Me.Hide()
                Dim StartGame As New DashBoard()
                StartGame.StartPosition = FormStartPosition.CenterScreen
                StartGame.Show()
            Else
                ' Display a message if login credentials are invalid
                MessageBox.Show("Invalid User. Please try again.")
            End If
        Catch ex As Exception
            ' Display an error message if an exception occurs
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub

    ' Function to check if the user exists in the database
    Private Function UserExists(ByVal username As String, ByVal password As String) As Boolean
        Try
            Using connection As New SqlConnection(connectionString)
                Using command As New SqlCommand(sqlSelectUser, connection)
                    connection.Open()
                    command.Parameters.AddWithValue("@Username", username)
                    command.Parameters.AddWithValue("@Password", password)

                    Using reader As SqlDataReader = command.ExecuteReader()
                        ' Return true if a user with the given credentials exists
                        Return reader.HasRows
                    End Using
                End Using
            End Using
        Catch ex As Exception
            ' Display an error message if an exception occurs
            MessageBox.Show("Error checking user existence: " & ex.Message)
            Return False
        End Try
    End Function

    ' Function to retrieve user data based on the username (optional)
    Private Function GetUserData(ByVal username As String) As DataTable
        Dim userData As New DataTable()

        Dim sqlSelectUserData As String = "SELECT * FROM Users WHERE Username=@Username"

        Try
            Using connection As New SqlConnection(connectionString)
                Using command As New SqlCommand(sqlSelectUserData, connection)
                    connection.Open()
                    command.Parameters.AddWithValue("@Username", username)

                    Using adapter As New SqlDataAdapter(command)
                        adapter.Fill(userData)
                    End Using
                End Using
            End Using
        Catch ex As Exception
            ' Display an error message if an exception occurs
            MessageBox.Show("Error retrieving user data: " & ex.Message)
        End Try

        Return userData
    End Function

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click
        Me.Hide()
        Dim RegistrationForm As New Registrationform()
        RegistrationForm.StartPosition = FormStartPosition.CenterScreen ' Center the registration form
        RegistrationForm.Show()
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged

        If txtPassword.PasswordChar = ControlChars.NullChar Then
            ' Check if the PasswordChar property of txtPassword is currently set to NullChar (password is visible).

            ' Password is currently visible, so hide it
            ' Set the PasswordChar property to '*' (or any character you prefer) for masking the password.
            txtPassword.PasswordChar = "*"c
        Else
            ' Password is currently masked (not visible).

            ' Password is currently masked, so show it
            ' Set the PasswordChar property to NullChar to display the password as plain text.
            txtPassword.PasswordChar = ControlChars.NullChar
        End If
    End Sub

    Private Sub btnExit_MouseEnter(ByVal sender As Object, ByVal e As EventArgs) Handles btnExit.MouseEnter
        btnExit.BackColor = Color.Red
    End Sub

    Private Sub btnExit_MouseLeave(ByVal sender As Object, ByVal e As EventArgs) Handles btnExit.MouseLeave
        btnExit.BackColor = SystemColors.Control
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub
    Private Sub btnMinimize_MouseEnter(ByVal sender As Object, ByVal e As EventArgs) Handles btnMinimize.MouseEnter
        btnMinimize.BackColor = Color.Gray
    End Sub

    Private Sub btnMinimize_MouseLeave(ByVal sender As Object, ByVal e As EventArgs) Handles btnMinimize.MouseLeave
        btnMinimize.BackColor = SystemColors.Control
    End Sub
    Private Sub btnMinimize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMinimize.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub
End Class
