﻿Public Class Level20
    Dim score As Integer = 0

    Private Sub SplitContainer1_Panel1_Paint_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles SplitContainer1.Panel1.Paint
        btn1.Enabled = False
        btn2.Enabled = False
        btn3.Enabled = False
        btn4.Enabled = False
        btn5.Enabled = False
        btn6.Enabled = False
        btn7.Enabled = False
        btn8.Enabled = False
        btn9.Enabled = False
        btn10.Enabled = False
        btn11.Enabled = False
        btn12.Enabled = False
        btn13.Enabled = False
        btn14.Enabled = False
        btn15.Enabled = False
        btn16.Enabled = False
        btn17.Enabled = False
        btn18.Enabled = False
        btn19.Enabled = False
        btn20.ForeColor = Color.Red
        btnNext.Hide()
        LabelScore.Hide()

    End Sub

    Private Sub btn20_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn20.Click
        LabelQuestion.Show()
        btnchoice1.Show()
        btnchoice2.Show()
        btnchoice3.Show()
        btnchoice4.Show()
    End Sub

    Private Sub SplitContainer1_Panel2_Paint_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles SplitContainer1.Panel2.Paint
        btnchoice1.Text = "while x> y:"
        btnchoice2.Text = "while x > y {"
        btnchoice3.Text = "while (x > y)"
        btnchoice4.Text = "x > y while {"
    End Sub

    Private Sub CheckAnswer(ByVal selectedChoice As String, ByVal selectedButton As Button, ByVal correctAnswer As String)

        If selectedChoice = correctAnswer Then
            selectedButton.BackColor = Color.Green
            score += 100
            UpdateScore()


            If selectedChoice = correctAnswer Then
                btnchoice1.Enabled = False
                btnchoice2.Enabled = False
                btnchoice3.Enabled = False
                btnchoice4.Enabled = False
            End If
        Else
            score += 50
            selectedButton.BackColor = Color.Red
            btnchoice1.Enabled = False
            btnchoice3.Enabled = False
            btnchoice2.Enabled = False
            btnchoice4.Enabled = False
            btnchoice3.BackColor = Color.Green
            UpdateScore()
        End If

    End Sub

    Private Sub UpdateScore()
        LabelScore.Text = "Score: " & score.ToString()
    End Sub

    'Wrong answer A
    Private Sub btnchoice1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnchoice1.Click
        CheckAnswer(btnchoice1.Text, btnchoice1, "incorrect")
        btnchoice1.Enabled = False
        btnNext.Show()
        LabelScore.Show()

    End Sub

    'Correct answer B
    Private Sub btnchoice2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnchoice3.Click
        CheckAnswer(btnchoice3.Text, btnchoice3, "incorrect")
        btnchoice3.Enabled = False
        btnNext.Show()
        LabelScore.Show()
    End Sub

    'Correct answers C
    Private Sub btnchoice3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnchoice2.Click
        CheckAnswer(btnchoice2.Text, btnchoice2, "while (x > y)")
        btnchoice2.Enabled = False
        btnNext.Show()
        LabelScore.Show()
    End Sub

    'Wrong answers D
    Private Sub btnchoice4_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnchoice4.Click
        CheckAnswer(btnchoice4.Text, btnchoice4, "incorrect")
        btnchoice4.Enabled = False
        btnNext.Show()
        LabelScore.Show()
    End Sub

    'Next Level
    Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click
        Me.Hide()
        Dim nextLevelForm As New FinishLevel()
        nextLevelForm.StartPosition = FormStartPosition.CenterScreen
        nextLevelForm.Show()
    End Sub

    Private Sub btnExit_MouseEnter(ByVal sender As Object, ByVal e As EventArgs) Handles btnExit.MouseEnter
        btnExit.BackColor = Color.Red
    End Sub

    Private Sub btnExit_MouseLeave(ByVal sender As Object, ByVal e As EventArgs) Handles btnExit.MouseLeave
        btnExit.BackColor = SystemColors.Control
    End Sub

    Private Sub btnExit_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub
    Private Sub btnMinimize_MouseEnter(ByVal sender As Object, ByVal e As EventArgs) Handles btnMinimize.MouseEnter
        btnMinimize.BackColor = Color.Gray
    End Sub

    Private Sub btnMinimize_MouseLeave(ByVal sender As Object, ByVal e As EventArgs) Handles btnMinimize.MouseLeave
        btnMinimize.BackColor = SystemColors.Control
    End Sub
    Private Sub btnMinimize_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMinimize.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    'Back to DashBoard 
    Private Sub btnBack_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBack.Click
        Me.Hide()
        Dim MainForm As New DashBoard()
        MainForm.StartPosition = FormStartPosition.CenterScreen
        MainForm.Show()
    End Sub
    Private Sub btnBack_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBack.MouseLeave
        btnBack.ForeColor = Color.Black
    End Sub

    Private Sub btnBack_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBack.MouseEnter
        btnBack.ForeColor = Color.Aqua
    End Sub

    'Help
    Private Sub lblGameInstructions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblGameInstructions.Click
        MessageBox.Show("Welcome to the game! Instructions:" & Chr(13) & "1.Click Level 1 to start the game." & Chr(13) & "2.Choose the correct answer from the choices." & Chr(13) & "3.Click Next to move to the next level.", "Game Instructions", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub
    Private Sub lblGameInstructions_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblGameInstructions.MouseEnter
        lblGameInstructions.ForeColor = Color.Aqua
    End Sub
    Private Sub lblGameInstructions_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblGameInstructions.MouseLeave
        lblGameInstructions.ForeColor = Color.Black
    End Sub
End Class