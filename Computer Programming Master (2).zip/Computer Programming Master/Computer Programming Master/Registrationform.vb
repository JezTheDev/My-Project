﻿Imports System.Data.SqlClient

Public Class Registrationform
    ' Connection string to the database
    Dim connectionString As String = "Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\velas\OneDrive\Documents\My-Project\Computer Programming Master\Computer Programming Master\RegistrationDB.mdf;Integrated Security=True;User Instance=True"


    ' SQL query to insert user data into the "Users" table
    Dim sqlInsert As String = "INSERT INTO Account (Name, Username, Password) VALUES (@Name, @Username, @Password)"

    ' Event handler for the Register button click
    Private Sub Registerbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Registerbtn.Click
            Try
                ' Using statement ensures that the connection is properly closed after use
                Using connection As New SqlConnection(connectionString)
                    ' Using statement ensures that the command is properly disposed of after use
                    Using command As New SqlCommand(sqlInsert, connection)
                        ' Open the database connection
                        connection.Open()

                        ' Check if the passwords match
                        If txtPassword.Text = txtConfirmPass.Text Then
                            ' Insert user data into the "Users" table
                            command.Parameters.AddWithValue("@Name", txtName.Text)
                            command.Parameters.AddWithValue("@Username", txtUserName.Text)
                            command.Parameters.AddWithValue("@Password", txtPassword.Text)
                            command.ExecuteNonQuery()

                            ' Display a success message
                        MessageBox.Show("Registration successful!")
                        Me.Hide()
                        Dim loginForm As New LoginForm()
                        loginForm.StartPosition = FormStartPosition.CenterScreen
                        loginForm.Show() ' Show the login form
                        Else
                            ' Display a message if passwords do not match
                            MessageBox.Show("Passwords do not match. Please try again.")
                        End If
                    End Using
                End Using

            Catch ex As Exception
                ' Display an error message if an exception occurs
                MessageBox.Show("Error: " & ex.Message)
            End Try
    End Sub

    Private Sub Label6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label6.Click
        Me.Hide()
        Dim loginForm As New LoginForm()
        loginForm.StartPosition = FormStartPosition.CenterScreen
        loginForm.Show() ' Show the login form
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged

        If txtPassword.PasswordChar = ControlChars.NullChar Then
            ' Check if the PasswordChar property of txtPassword is currently set to NullChar (password is visible).

            ' Password is currently visible, so hide it
            ' Set the PasswordChar property to '*' (or any character you prefer) for masking the password.
            txtPassword.PasswordChar = "*"c
        Else
            ' Password is currently masked (not visible).

            ' Password is currently masked, so show it
            ' Set the PasswordChar property to NullChar to display the password as plain text.
            txtPassword.PasswordChar = ControlChars.NullChar
        End If
    End Sub

    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged

        If txtConfirmPass.PasswordChar = ControlChars.NullChar Then
            ' Check if the PasswordChar property of txtPassword is currently set to NullChar (password is visible).

            ' Password is currently visible, so hide it
            ' Set the PasswordChar property to '*' (or any character you prefer) for masking the password.
            txtConfirmPass.PasswordChar = "*"c
        Else
            ' Password is currently masked (not visible).

            ' Password is currently masked, so show it
            ' Set the PasswordChar property to NullChar to display the password as plain text.
            txtConfirmPass.PasswordChar = ControlChars.NullChar
        End If

    End Sub

    Private Sub btnExit_MouseEnter(ByVal sender As Object, ByVal e As EventArgs) Handles btnExit.MouseEnter
        btnExit.BackColor = Color.Red
    End Sub

    Private Sub btnExit_MouseLeave(ByVal sender As Object, ByVal e As EventArgs) Handles btnExit.MouseLeave
        btnExit.BackColor = SystemColors.Control
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub
    Private Sub btnMinimize_MouseEnter(ByVal sender As Object, ByVal e As EventArgs) Handles btnMinimize.MouseEnter
        btnMinimize.BackColor = Color.Gray
    End Sub

    Private Sub btnMinimize_MouseLeave(ByVal sender As Object, ByVal e As EventArgs) Handles btnMinimize.MouseLeave
        btnMinimize.BackColor = SystemColors.Control
    End Sub
    Private Sub btnMinimize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMinimize.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub
End Class
