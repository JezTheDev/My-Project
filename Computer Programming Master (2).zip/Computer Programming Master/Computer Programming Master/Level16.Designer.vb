﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Level16
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnchoice3 = New System.Windows.Forms.Button()
        Me.btn10 = New System.Windows.Forms.Button()
        Me.btn9 = New System.Windows.Forms.Button()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.btnBack = New System.Windows.Forms.Label()
        Me.lblGameInstructions = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btn20 = New System.Windows.Forms.Button()
        Me.btn19 = New System.Windows.Forms.Button()
        Me.btn18 = New System.Windows.Forms.Button()
        Me.btn17 = New System.Windows.Forms.Button()
        Me.btn16 = New System.Windows.Forms.Button()
        Me.btn15 = New System.Windows.Forms.Button()
        Me.btn14 = New System.Windows.Forms.Button()
        Me.btn13 = New System.Windows.Forms.Button()
        Me.btn12 = New System.Windows.Forms.Button()
        Me.btn11 = New System.Windows.Forms.Button()
        Me.btn8 = New System.Windows.Forms.Button()
        Me.btn7 = New System.Windows.Forms.Button()
        Me.btn6 = New System.Windows.Forms.Button()
        Me.btn5 = New System.Windows.Forms.Button()
        Me.btn4 = New System.Windows.Forms.Button()
        Me.btn3 = New System.Windows.Forms.Button()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.LabelQuestion = New System.Windows.Forms.Label()
        Me.btnMinimize = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.LabelScore = New System.Windows.Forms.Label()
        Me.btnchoice4 = New System.Windows.Forms.Button()
        Me.btnchoice2 = New System.Windows.Forms.Button()
        Me.btnchoice1 = New System.Windows.Forms.Button()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnchoice3
        '
        Me.btnchoice3.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btnchoice3.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btnchoice3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnchoice3.FlatAppearance.BorderColor = System.Drawing.Color.DimGray
        Me.btnchoice3.FlatAppearance.BorderSize = 2
        Me.btnchoice3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray
        Me.btnchoice3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray
        Me.btnchoice3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnchoice3.Font = New System.Drawing.Font("Calibri", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnchoice3.ForeColor = System.Drawing.Color.Black
        Me.btnchoice3.Location = New System.Drawing.Point(39, 517)
        Me.btnchoice3.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnchoice3.Name = "btnchoice3"
        Me.btnchoice3.Size = New System.Drawing.Size(295, 64)
        Me.btnchoice3.TabIndex = 20
        Me.btnchoice3.UseVisualStyleBackColor = False
        '
        'btn10
        '
        Me.btn10.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btn10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btn10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn10.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen
        Me.btn10.FlatAppearance.BorderSize = 2
        Me.btn10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray
        Me.btn10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSeaGreen
        Me.btn10.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn10.Font = New System.Drawing.Font("Stencil", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn10.ForeColor = System.Drawing.Color.Black
        Me.btn10.Location = New System.Drawing.Point(297, 327)
        Me.btn10.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btn10.Name = "btn10"
        Me.btn10.Size = New System.Drawing.Size(59, 49)
        Me.btn10.TabIndex = 32
        Me.btn10.Text = "10"
        Me.btn10.UseVisualStyleBackColor = False
        '
        'btn9
        '
        Me.btn9.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btn9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btn9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn9.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen
        Me.btn9.FlatAppearance.BorderSize = 2
        Me.btn9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray
        Me.btn9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSeaGreen
        Me.btn9.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn9.Font = New System.Drawing.Font("Stencil", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn9.ForeColor = System.Drawing.Color.Black
        Me.btn9.Location = New System.Drawing.Point(229, 350)
        Me.btn9.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btn9.Name = "btn9"
        Me.btn9.Size = New System.Drawing.Size(59, 49)
        Me.btn9.TabIndex = 31
        Me.btn9.Text = "9"
        Me.btn9.UseVisualStyleBackColor = False
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.BackColor = System.Drawing.Color.DarkSlateGray
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnBack)
        Me.SplitContainer1.Panel1.Controls.Add(Me.lblGameInstructions)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Label1)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btn20)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btn19)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btn18)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btn17)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btn16)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btn15)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btn14)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btn13)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btn12)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btn11)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btn10)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btn9)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btn8)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btn7)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btn6)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btn5)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btn4)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btn3)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btn2)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btn1)
        Me.SplitContainer1.Panel1.ForeColor = System.Drawing.Color.Black
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.BackgroundImage = Global.Computer_Programming_Master.My.Resources.Resources._3
        Me.SplitContainer1.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.SplitContainer1.Panel2.Controls.Add(Me.Label2)
        Me.SplitContainer1.Panel2.Controls.Add(Me.LabelQuestion)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnMinimize)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnExit)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnNext)
        Me.SplitContainer1.Panel2.Controls.Add(Me.LabelScore)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnchoice4)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnchoice3)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnchoice2)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnchoice1)
        Me.SplitContainer1.Size = New System.Drawing.Size(1179, 690)
        Me.SplitContainer1.SplitterDistance = 392
        Me.SplitContainer1.TabIndex = 14
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.Color.Transparent
        Me.btnBack.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBack.Font = New System.Drawing.Font("Cooper Black", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Location = New System.Drawing.Point(3, 0)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(85, 63)
        Me.btnBack.TabIndex = 76
        Me.btnBack.Text = "←"
        Me.btnBack.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGameInstructions
        '
        Me.lblGameInstructions.AutoSize = True
        Me.lblGameInstructions.BackColor = System.Drawing.Color.Transparent
        Me.lblGameInstructions.Cursor = System.Windows.Forms.Cursors.Hand
        Me.lblGameInstructions.Location = New System.Drawing.Point(349, 11)
        Me.lblGameInstructions.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblGameInstructions.Name = "lblGameInstructions"
        Me.lblGameInstructions.Size = New System.Drawing.Size(37, 17)
        Me.lblGameInstructions.TabIndex = 75
        Me.lblGameInstructions.Text = "Help"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Stencil", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(75, 98)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(240, 71)
        Me.Label1.TabIndex = 43
        Me.Label1.Text = "LEVELS"
        '
        'btn20
        '
        Me.btn20.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btn20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btn20.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn20.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen
        Me.btn20.FlatAppearance.BorderSize = 2
        Me.btn20.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray
        Me.btn20.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSeaGreen
        Me.btn20.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn20.Font = New System.Drawing.Font("Stencil", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn20.ForeColor = System.Drawing.Color.Black
        Me.btn20.Location = New System.Drawing.Point(297, 549)
        Me.btn20.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btn20.Name = "btn20"
        Me.btn20.Size = New System.Drawing.Size(59, 49)
        Me.btn20.TabIndex = 42
        Me.btn20.Text = "20"
        Me.btn20.UseVisualStyleBackColor = False
        '
        'btn19
        '
        Me.btn19.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btn19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btn19.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn19.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen
        Me.btn19.FlatAppearance.BorderSize = 2
        Me.btn19.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray
        Me.btn19.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSeaGreen
        Me.btn19.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn19.Font = New System.Drawing.Font("Stencil", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn19.ForeColor = System.Drawing.Color.Black
        Me.btn19.Location = New System.Drawing.Point(229, 574)
        Me.btn19.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btn19.Name = "btn19"
        Me.btn19.Size = New System.Drawing.Size(59, 49)
        Me.btn19.TabIndex = 41
        Me.btn19.Text = "19"
        Me.btn19.UseVisualStyleBackColor = False
        '
        'btn18
        '
        Me.btn18.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btn18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btn18.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn18.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen
        Me.btn18.FlatAppearance.BorderSize = 2
        Me.btn18.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray
        Me.btn18.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSeaGreen
        Me.btn18.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn18.Font = New System.Drawing.Font("Stencil", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn18.ForeColor = System.Drawing.Color.Black
        Me.btn18.Location = New System.Drawing.Point(163, 549)
        Me.btn18.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btn18.Name = "btn18"
        Me.btn18.Size = New System.Drawing.Size(59, 49)
        Me.btn18.TabIndex = 40
        Me.btn18.Text = "18"
        Me.btn18.UseVisualStyleBackColor = False
        '
        'btn17
        '
        Me.btn17.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btn17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btn17.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn17.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen
        Me.btn17.FlatAppearance.BorderSize = 2
        Me.btn17.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray
        Me.btn17.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSeaGreen
        Me.btn17.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn17.Font = New System.Drawing.Font("Stencil", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn17.ForeColor = System.Drawing.Color.Black
        Me.btn17.Location = New System.Drawing.Point(97, 574)
        Me.btn17.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btn17.Name = "btn17"
        Me.btn17.Size = New System.Drawing.Size(59, 49)
        Me.btn17.TabIndex = 39
        Me.btn17.Text = "17"
        Me.btn17.UseVisualStyleBackColor = False
        '
        'btn16
        '
        Me.btn16.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btn16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btn16.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn16.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen
        Me.btn16.FlatAppearance.BorderSize = 2
        Me.btn16.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray
        Me.btn16.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSeaGreen
        Me.btn16.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn16.Font = New System.Drawing.Font("Stencil", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn16.ForeColor = System.Drawing.Color.Black
        Me.btn16.Location = New System.Drawing.Point(29, 549)
        Me.btn16.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btn16.Name = "btn16"
        Me.btn16.Size = New System.Drawing.Size(59, 49)
        Me.btn16.TabIndex = 38
        Me.btn16.Text = "16"
        Me.btn16.UseVisualStyleBackColor = False
        '
        'btn15
        '
        Me.btn15.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btn15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btn15.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn15.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen
        Me.btn15.FlatAppearance.BorderSize = 2
        Me.btn15.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray
        Me.btn15.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSeaGreen
        Me.btn15.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn15.Font = New System.Drawing.Font("Stencil", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn15.ForeColor = System.Drawing.Color.Black
        Me.btn15.Location = New System.Drawing.Point(297, 442)
        Me.btn15.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btn15.Name = "btn15"
        Me.btn15.Size = New System.Drawing.Size(59, 49)
        Me.btn15.TabIndex = 37
        Me.btn15.Text = "15"
        Me.btn15.UseVisualStyleBackColor = False
        '
        'btn14
        '
        Me.btn14.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btn14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btn14.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn14.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen
        Me.btn14.FlatAppearance.BorderSize = 2
        Me.btn14.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray
        Me.btn14.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSeaGreen
        Me.btn14.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn14.Font = New System.Drawing.Font("Stencil", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn14.ForeColor = System.Drawing.Color.Black
        Me.btn14.Location = New System.Drawing.Point(229, 455)
        Me.btn14.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btn14.Name = "btn14"
        Me.btn14.Size = New System.Drawing.Size(59, 49)
        Me.btn14.TabIndex = 36
        Me.btn14.Text = "14"
        Me.btn14.UseVisualStyleBackColor = False
        '
        'btn13
        '
        Me.btn13.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btn13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btn13.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn13.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen
        Me.btn13.FlatAppearance.BorderSize = 2
        Me.btn13.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray
        Me.btn13.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSeaGreen
        Me.btn13.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn13.Font = New System.Drawing.Font("Stencil", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn13.ForeColor = System.Drawing.Color.Black
        Me.btn13.Location = New System.Drawing.Point(163, 442)
        Me.btn13.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btn13.Name = "btn13"
        Me.btn13.Size = New System.Drawing.Size(59, 49)
        Me.btn13.TabIndex = 35
        Me.btn13.Text = "13"
        Me.btn13.UseVisualStyleBackColor = False
        '
        'btn12
        '
        Me.btn12.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btn12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btn12.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn12.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen
        Me.btn12.FlatAppearance.BorderSize = 2
        Me.btn12.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray
        Me.btn12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSeaGreen
        Me.btn12.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn12.Font = New System.Drawing.Font("Stencil", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn12.ForeColor = System.Drawing.Color.Black
        Me.btn12.Location = New System.Drawing.Point(97, 455)
        Me.btn12.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btn12.Name = "btn12"
        Me.btn12.Size = New System.Drawing.Size(59, 49)
        Me.btn12.TabIndex = 34
        Me.btn12.Text = "12"
        Me.btn12.UseVisualStyleBackColor = False
        '
        'btn11
        '
        Me.btn11.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btn11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btn11.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn11.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen
        Me.btn11.FlatAppearance.BorderSize = 2
        Me.btn11.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray
        Me.btn11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSeaGreen
        Me.btn11.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn11.Font = New System.Drawing.Font("Stencil", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn11.ForeColor = System.Drawing.Color.Black
        Me.btn11.Location = New System.Drawing.Point(29, 442)
        Me.btn11.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btn11.Name = "btn11"
        Me.btn11.Size = New System.Drawing.Size(59, 49)
        Me.btn11.TabIndex = 33
        Me.btn11.Text = "11"
        Me.btn11.UseVisualStyleBackColor = False
        '
        'btn8
        '
        Me.btn8.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btn8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btn8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn8.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen
        Me.btn8.FlatAppearance.BorderSize = 2
        Me.btn8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray
        Me.btn8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSeaGreen
        Me.btn8.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn8.Font = New System.Drawing.Font("Stencil", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn8.ForeColor = System.Drawing.Color.Black
        Me.btn8.Location = New System.Drawing.Point(163, 327)
        Me.btn8.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btn8.Name = "btn8"
        Me.btn8.Size = New System.Drawing.Size(59, 49)
        Me.btn8.TabIndex = 30
        Me.btn8.Text = "8"
        Me.btn8.UseVisualStyleBackColor = False
        '
        'btn7
        '
        Me.btn7.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btn7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btn7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn7.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen
        Me.btn7.FlatAppearance.BorderSize = 2
        Me.btn7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray
        Me.btn7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSeaGreen
        Me.btn7.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn7.Font = New System.Drawing.Font("Stencil", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn7.ForeColor = System.Drawing.Color.Black
        Me.btn7.Location = New System.Drawing.Point(97, 350)
        Me.btn7.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btn7.Name = "btn7"
        Me.btn7.Size = New System.Drawing.Size(59, 49)
        Me.btn7.TabIndex = 7
        Me.btn7.Text = "7"
        Me.btn7.UseVisualStyleBackColor = False
        '
        'btn6
        '
        Me.btn6.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btn6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btn6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn6.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen
        Me.btn6.FlatAppearance.BorderSize = 2
        Me.btn6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray
        Me.btn6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSeaGreen
        Me.btn6.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn6.Font = New System.Drawing.Font("Stencil", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn6.ForeColor = System.Drawing.Color.Black
        Me.btn6.Location = New System.Drawing.Point(29, 327)
        Me.btn6.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btn6.Name = "btn6"
        Me.btn6.Size = New System.Drawing.Size(59, 49)
        Me.btn6.TabIndex = 6
        Me.btn6.Text = "6"
        Me.btn6.UseVisualStyleBackColor = False
        '
        'btn5
        '
        Me.btn5.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btn5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btn5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn5.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen
        Me.btn5.FlatAppearance.BorderSize = 2
        Me.btn5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray
        Me.btn5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSeaGreen
        Me.btn5.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn5.Font = New System.Drawing.Font("Stencil", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn5.ForeColor = System.Drawing.Color.Black
        Me.btn5.Location = New System.Drawing.Point(297, 219)
        Me.btn5.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btn5.Name = "btn5"
        Me.btn5.Size = New System.Drawing.Size(59, 49)
        Me.btn5.TabIndex = 5
        Me.btn5.Text = "5"
        Me.btn5.UseVisualStyleBackColor = False
        '
        'btn4
        '
        Me.btn4.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btn4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btn4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn4.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen
        Me.btn4.FlatAppearance.BorderSize = 2
        Me.btn4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray
        Me.btn4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSeaGreen
        Me.btn4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn4.Font = New System.Drawing.Font("Stencil", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn4.ForeColor = System.Drawing.Color.Black
        Me.btn4.Location = New System.Drawing.Point(229, 233)
        Me.btn4.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btn4.Name = "btn4"
        Me.btn4.Size = New System.Drawing.Size(59, 49)
        Me.btn4.TabIndex = 4
        Me.btn4.Text = "4"
        Me.btn4.UseVisualStyleBackColor = False
        '
        'btn3
        '
        Me.btn3.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btn3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btn3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn3.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen
        Me.btn3.FlatAppearance.BorderSize = 2
        Me.btn3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray
        Me.btn3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSeaGreen
        Me.btn3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn3.Font = New System.Drawing.Font("Stencil", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn3.ForeColor = System.Drawing.Color.Black
        Me.btn3.Location = New System.Drawing.Point(163, 219)
        Me.btn3.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(59, 49)
        Me.btn3.TabIndex = 3
        Me.btn3.Text = "3"
        Me.btn3.UseVisualStyleBackColor = False
        '
        'btn2
        '
        Me.btn2.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btn2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btn2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn2.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen
        Me.btn2.FlatAppearance.BorderSize = 2
        Me.btn2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray
        Me.btn2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSeaGreen
        Me.btn2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn2.Font = New System.Drawing.Font("Stencil", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn2.ForeColor = System.Drawing.Color.Black
        Me.btn2.Location = New System.Drawing.Point(97, 233)
        Me.btn2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(59, 49)
        Me.btn2.TabIndex = 2
        Me.btn2.Text = "2"
        Me.btn2.UseVisualStyleBackColor = False
        '
        'btn1
        '
        Me.btn1.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btn1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btn1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn1.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen
        Me.btn1.FlatAppearance.BorderSize = 2
        Me.btn1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray
        Me.btn1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSeaGreen
        Me.btn1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn1.Font = New System.Drawing.Font("Stencil", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn1.ForeColor = System.Drawing.Color.Black
        Me.btn1.Location = New System.Drawing.Point(29, 219)
        Me.btn1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(59, 49)
        Me.btn1.TabIndex = 1
        Me.btn1.Text = "1"
        Me.btn1.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Sitka Banner", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Aqua
        Me.Label2.Location = New System.Drawing.Point(23, 15)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(232, 87)
        Me.Label2.TabIndex = 78
        Me.Label2.Text = "Level 16"
        '
        'LabelQuestion
        '
        Me.LabelQuestion.BackColor = System.Drawing.Color.LightSeaGreen
        Me.LabelQuestion.Font = New System.Drawing.Font("Calibri", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelQuestion.Location = New System.Drawing.Point(85, 219)
        Me.LabelQuestion.Name = "LabelQuestion"
        Me.LabelQuestion.Size = New System.Drawing.Size(595, 118)
        Me.LabelQuestion.TabIndex = 26
        Me.LabelQuestion.Text = "Which keyword is used to create a class in Java?"
        Me.LabelQuestion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnMinimize
        '
        Me.btnMinimize.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnMinimize.BackColor = System.Drawing.Color.Gainsboro
        Me.btnMinimize.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnMinimize.FlatAppearance.BorderColor = System.Drawing.Color.Red
        Me.btnMinimize.FlatAppearance.BorderSize = 0
        Me.btnMinimize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.btnMinimize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnMinimize.Font = New System.Drawing.Font("Matura MT Script Capitals", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMinimize.Location = New System.Drawing.Point(691, 15)
        Me.btnMinimize.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnMinimize.Name = "btnMinimize"
        Me.btnMinimize.Size = New System.Drawing.Size(36, 28)
        Me.btnMinimize.TabIndex = 25
        Me.btnMinimize.Text = "-"
        Me.btnMinimize.UseVisualStyleBackColor = False
        '
        'btnExit
        '
        Me.btnExit.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnExit.BackColor = System.Drawing.Color.Gainsboro
        Me.btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnExit.FlatAppearance.BorderColor = System.Drawing.Color.Red
        Me.btnExit.FlatAppearance.BorderSize = 0
        Me.btnExit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.btnExit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnExit.Font = New System.Drawing.Font("Malgun Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(733, 15)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(36, 28)
        Me.btnExit.TabIndex = 24
        Me.btnExit.Text = "X"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'btnNext
        '
        Me.btnNext.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnNext.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btnNext.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnNext.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnNext.FlatAppearance.BorderColor = System.Drawing.Color.DimGray
        Me.btnNext.FlatAppearance.BorderSize = 2
        Me.btnNext.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray
        Me.btnNext.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray
        Me.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnNext.Font = New System.Drawing.Font("Verdana", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNext.Location = New System.Drawing.Point(632, 639)
        Me.btnNext.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(137, 37)
        Me.btnNext.TabIndex = 23
        Me.btnNext.Text = "Next"
        Me.btnNext.UseVisualStyleBackColor = False
        '
        'LabelScore
        '
        Me.LabelScore.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LabelScore.AutoSize = True
        Me.LabelScore.BackColor = System.Drawing.Color.LightSeaGreen
        Me.LabelScore.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelScore.ForeColor = System.Drawing.Color.Black
        Me.LabelScore.Location = New System.Drawing.Point(635, 609)
        Me.LabelScore.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelScore.Name = "LabelScore"
        Me.LabelScore.Size = New System.Drawing.Size(99, 25)
        Me.LabelScore.TabIndex = 22
        Me.LabelScore.Text = "Score = "
        '
        'btnchoice4
        '
        Me.btnchoice4.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btnchoice4.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btnchoice4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnchoice4.FlatAppearance.BorderColor = System.Drawing.Color.DimGray
        Me.btnchoice4.FlatAppearance.BorderSize = 2
        Me.btnchoice4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray
        Me.btnchoice4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray
        Me.btnchoice4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnchoice4.Font = New System.Drawing.Font("Calibri", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnchoice4.ForeColor = System.Drawing.Color.Black
        Me.btnchoice4.Location = New System.Drawing.Point(453, 517)
        Me.btnchoice4.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnchoice4.Name = "btnchoice4"
        Me.btnchoice4.Size = New System.Drawing.Size(295, 64)
        Me.btnchoice4.TabIndex = 21
        Me.btnchoice4.UseVisualStyleBackColor = False
        '
        'btnchoice2
        '
        Me.btnchoice2.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btnchoice2.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btnchoice2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnchoice2.FlatAppearance.BorderColor = System.Drawing.Color.DimGray
        Me.btnchoice2.FlatAppearance.BorderSize = 2
        Me.btnchoice2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray
        Me.btnchoice2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray
        Me.btnchoice2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnchoice2.Font = New System.Drawing.Font("Calibri", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnchoice2.ForeColor = System.Drawing.Color.Black
        Me.btnchoice2.Location = New System.Drawing.Point(453, 427)
        Me.btnchoice2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnchoice2.Name = "btnchoice2"
        Me.btnchoice2.Size = New System.Drawing.Size(295, 64)
        Me.btnchoice2.TabIndex = 19
        Me.btnchoice2.UseVisualStyleBackColor = False
        '
        'btnchoice1
        '
        Me.btnchoice1.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btnchoice1.BackColor = System.Drawing.Color.LightSeaGreen
        Me.btnchoice1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnchoice1.FlatAppearance.BorderColor = System.Drawing.Color.DimGray
        Me.btnchoice1.FlatAppearance.BorderSize = 2
        Me.btnchoice1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray
        Me.btnchoice1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray
        Me.btnchoice1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnchoice1.Font = New System.Drawing.Font("Calibri", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnchoice1.ForeColor = System.Drawing.Color.Black
        Me.btnchoice1.Location = New System.Drawing.Point(39, 427)
        Me.btnchoice1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnchoice1.Name = "btnchoice1"
        Me.btnchoice1.Size = New System.Drawing.Size(295, 64)
        Me.btnchoice1.TabIndex = 18
        Me.btnchoice1.UseVisualStyleBackColor = False
        '
        'Level16
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1179, 690)
        Me.Controls.Add(Me.SplitContainer1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "Level16"
        Me.Text = "Level16"
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.PerformLayout()
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.Panel2.PerformLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnchoice3 As System.Windows.Forms.Button
    Friend WithEvents btn10 As System.Windows.Forms.Button
    Friend WithEvents btn9 As System.Windows.Forms.Button
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btn20 As System.Windows.Forms.Button
    Friend WithEvents btn19 As System.Windows.Forms.Button
    Friend WithEvents btn18 As System.Windows.Forms.Button
    Friend WithEvents btn17 As System.Windows.Forms.Button
    Friend WithEvents btn16 As System.Windows.Forms.Button
    Friend WithEvents btn15 As System.Windows.Forms.Button
    Friend WithEvents btn14 As System.Windows.Forms.Button
    Friend WithEvents btn13 As System.Windows.Forms.Button
    Friend WithEvents btn12 As System.Windows.Forms.Button
    Friend WithEvents btn11 As System.Windows.Forms.Button
    Friend WithEvents btn8 As System.Windows.Forms.Button
    Friend WithEvents btn7 As System.Windows.Forms.Button
    Friend WithEvents btn6 As System.Windows.Forms.Button
    Friend WithEvents btn5 As System.Windows.Forms.Button
    Friend WithEvents btn4 As System.Windows.Forms.Button
    Friend WithEvents btn3 As System.Windows.Forms.Button
    Friend WithEvents btn2 As System.Windows.Forms.Button
    Friend WithEvents btn1 As System.Windows.Forms.Button
    Friend WithEvents LabelQuestion As System.Windows.Forms.Label
    Friend WithEvents btnMinimize As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents btnNext As System.Windows.Forms.Button
    Friend WithEvents LabelScore As System.Windows.Forms.Label
    Friend WithEvents btnchoice4 As System.Windows.Forms.Button
    Friend WithEvents btnchoice2 As System.Windows.Forms.Button
    Friend WithEvents btnchoice1 As System.Windows.Forms.Button
    Friend WithEvents btnBack As System.Windows.Forms.Label
    Friend WithEvents lblGameInstructions As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
End Class
